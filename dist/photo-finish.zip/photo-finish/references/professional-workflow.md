# 专业摄影判断与多步精修

现行2026-10-23.4。由执行助手独立做摄影判断，无新增用户确认。审美、构图、强度与手法不设统一上限；去AI味、真实内容和实际文件验收继续有效。

1. 先看原片，明确视觉意图、主体与次要层级、光线/材质、输出用途，再选手法。用delivery_automation.py direction(path,intent,hierarchy,light_material,output_use,route,qa_focus)在首轮提交前保存精简决策；output_use为screen或print_proof_requested，route为native/creative/hybrid。该记录不是美学通过或打印认证，不要求固定调参表。默认常规屏幕成片，不因缺RAW或打印标定而阻断它。
2. 参考候选传入已有意图的intent，先以元数据subject/light/material/expression解释适配性，再辅助明暗色彩排序；并非自动视觉判断。实际外部调用统一经delivery_adapter。参考候选仅为检索入口：实际比较光线方向与软硬、材质、主体语义、空间层次、预期情绪，再决定adopt/partial/reject/unavailable。把可迁移维度写入scope；同色不同光不强套白平衡，同场景不同意图不强套影调。候选不足或均不合适，立即进入专业判断，不等待补库、不伪称风格匹配。原片足以支持时独立建立新风格。
3. 能用光色、裁切、透视或局部明暗实现的目标，优先用实际可用的非生成工具保留摄影细节；需要扩展或重塑时可用creative/hybrid，不以“原生”限制创作。文字/画作保留原图可见内容：生成结果发生变化则回退或保留原区域，不补写猜测的字，不加逐笔认证。
4. 合并可兼容的全局参数；只有构图、操作顺序或局部控制确有收益才分步。每步取得正式字节，实际看全幅、检查尺寸/色彩，必要细节通过后才做依赖该输出的下一步。delivery_adapter.next-step(path,tool_name,arguments)从最新已核验输出生成新submission_id，保留历史与原片；实际结果回填相同令牌。working/unknown/未取回/未复核不能冒充下一步。不用重新建源任务绕过保护契约。每步蒙版绑定当步实际输入，不能沿用变更几何前的旧蒙版。
5. 复核按本次操作覆盖：每片看全幅；原生尺寸只检查本次受影响的主体、文字、纹理、亮暗边缘和蒙版过渡。裁切检查重心/边缘/新尺寸；局部调整检查选区及边缘，并用实际蒙版检查选区外变化；生成操作检查结构、重复纹理和保护内容。未受影响区域不反复生成报告或裁片；边界异常再扩大检查。不是免检，也不以数值代替审美。
6. 以原片实际可用信息决定降噪、锐化与尺寸，避免为了“高清”制造纹理；保留有意的颗粒、薄雾、暗部和混合色温。不能恢复的高光/运动模糊不宣称还原真实细节。打印用途单独获取介质ICC、软打样与目标尺寸；没有这些仍可交屏幕成片，不能声称已标定打印色准。P3正确嵌入并不等于已转换sRGB；转换必须用真实色彩管理引擎，不能只改标签。
7. 批量按相同光照建立基准，只迁移明确可共用的字段；逐张核对曝光、白平衡、几何、蒙版和噪声。规模/RAW/肤色/打印能力只按实际案例记录，不因单例通过自动扩展认证。默认编辑不跑维护回归、不补长报告。工具故障保留已得正式结果与任务状态，在保持目标和保真条件下选可用路线；不以反复重渲染或降低验收掩盖故障。

方法依据（2026-10-22检索）：
- [Adobe非破坏编辑](https://helpx.adobe.com/photoshop/desktop/create-manage-layers/create-layer-compositions/non-destructive-editing-techniques.html)：保留原始数据与可回退的操作；当前接口输出为独立PNG和配方记录，不冒称提供分层PSD。
- [Adobe局部蒙版](https://helpx.adobe.com/lightroom-classic/desktop/process-and-develop-photos/masking.html)：局部光色控制与边缘复核；当前工具仅以实际返回的蒙版为准。
- [Adobe色彩与软打样](https://helpx.adobe.com/lightroom-classic/desktop/technical-support/technical-issues/miscellaneous-issues/color-faq.html)：按屏幕/印刷用途与真实ICC区分交付能力。

默认把画面表达做得明显更充分：主动完成构图、主次光影、色彩与材质；去AI味和题字一致不等于保守微调。终检须实际比较表达目标与结果，技术通过不能替代表达完成。未落实的表达关系继续针对性修正；不机械套暖金/高饱和，也不强制每片大改。
